# Legacy notes – feedback validator (Lab 05)

**Student:** Rayyan Hurain · **Roll No.:** 0108 · Web Engineering, Sir Syed CASE Institute of Technology

The file `public/legacy-feedback.js` validates the feedback form with jQuery 3.7.1.
Before porting it I translated every jQuery call into the DOM API the browser already has.

## 1. jQuery call → native equivalent

| # | jQuery call in the script | Native JavaScript | What changes |
|---|---------------------------|-------------------|--------------|
| 1 | `$(document).ready(fn)` | `<script type="module">` (deferred by default) or `document.addEventListener("DOMContentLoaded", fn)` | A module only runs after the HTML is parsed, so no wrapper is needed at all. |
| 2 | `$("#name").val()` | `document.querySelector("#name").value` | jQuery returns a wrapped set; `querySelector` returns the element itself (or `null`). |
| 3 | `$("#name").after('<span class="error">…</span>')` | `const s = document.createElement("span"); s.className = "error"; s.textContent = msg; input.after(s);` | Build a real node instead of parsing an HTML string. `Element.after()` is native. |
| 4 | `$(".error").remove()` | `form.querySelectorAll(".error").forEach((el) => el.remove())` | `querySelectorAll` returns a static `NodeList`; each element removes itself. |
| 5 | `$("#status").text(msg).hide().fadeIn(400)` | `status.textContent = msg;` (fade dropped, or a CSS `transition` on `opacity`) | `textContent` never parses HTML. Animation belongs in CSS, so the port drops `fadeIn`. |
| 6 | `$form[0].reset()` | `form.reset()` | `[0]` unwraps the jQuery object to the real `<form>`; native code already holds the element. |

## 2. Legacy smells in the script

1. **`var` everywhere.** `var` is function-scoped and can be re-declared silently.
   Modern code uses `const` by default and `let` only for values that change (`valid`).
2. **`$.trim(...)`.** A jQuery helper from the days before `String.prototype.trim()` (ES5, 2009).
   It was removed in jQuery 4, so this exact file breaks if the CDN version is not pinned to 3.7.1.
3. **HTML built from strings.** `.after('<span class="error">…</span>')` makes the browser
   parse markup. With user data this is an XSS risk, and it skips accessibility attributes.
   The port builds the element with `createElement`, sets `textContent`, and adds `role="alert"`.
4. **`indexOf("@") === -1`.** A "not found" sentinel check. `!email.includes("@")` says the same thing
   in words. (Also: `function () {}` callbacks and `"Thanks, " + name + "!"` concatenation, now
   replaced by arrow functions and template literals.)

## 3. Evidence

- Network panel, legacy version: `jquery-3.7.1.min.js` – 200 – script – 87.7 kB.
- Network panel, native version: jQuery request no longer listed (one fewer script, ~88 kB less).

## 4. TypeScript – first errors from `npm run typecheck`

_(recorded after `git mv` of the three scripts into `src/`, before adding any types)_

`npm run typecheck` reported **27 errors in 4 files**. Two that taught me something:

1. `src/main.ts(14,18): error TS18047: 'event.target' is possibly 'null'.` and
   `TS2339: Property 'closest' does not exist on type 'EventTarget'.`
   `event.target` is typed `EventTarget | null` – it might be `window`, a text node, or nothing.
   Plain JS just assumed it was an element. Fix: narrow with `if (!(target instanceof Element)) return;`.
2. `src/feedback.ts(5,7): error TS2451: Cannot redeclare block-scoped variable 'status'.`
   (`lib.dom.d.ts: 'status' was also declared here.`)
   `feedback.ts` had no `import`/`export`, so TypeScript treated it as a *global script*, and my
   `const status` collided with the built-in `window.status`. Adding `import { getRequired } from "./utils.js"`
   makes the file a module with its own scope, and the error disappears.

Other errors in the list: `'form' is possibly 'null'` (querySelector can return null),
`Parameter 'ms' implicitly has an 'any' type` (strict mode forbids silent `any`), and
`'slot' is possibly 'undefined'` (`Array.find` may find nothing).
