// utils.ts – typed helpers shared by main.ts and feedback.ts

/** One office-hours slot. Any object with these four string properties is a Slot. */
export interface Slot {
  day: string;
  start: string;
  end: string;
  room: string;
}

/** Resolve after `ms` milliseconds. */
export const delay = (ms: number): Promise<void> =>
  new Promise((resolve) => setTimeout(resolve, ms));

/** Return a function that counts 1, 2, 3, … each time it is called. */
export function makeCounter(): () => number {
  let count = 0;
  return () => ++count;
}

/**
 * querySelector that never returns null.
 * The caller chooses the element type: getRequired<HTMLInputElement>("#name").
 */
export function getRequired<T extends Element>(
  selector: string,
  root: ParentNode = document,
): T {
  const element = root.querySelector<T>(selector);
  if (element === null) {
    throw new Error(`Missing element: ${selector}`);
  }
  return element;
}

export function describeSlot(slot: Slot): string {
  return `${slot.day} ${slot.start}–${slot.end}, ${slot.room}`;
}
