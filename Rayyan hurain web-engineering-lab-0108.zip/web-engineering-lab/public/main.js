// main.ts – office-hours booking, typed (Lab 05 Part B)
import { delay, makeCounter, getRequired, describeSlot } from "./utils.js";
const slots = [
    { day: "Monday", start: "10:00", end: "11:00", room: "Room 214" },
    { day: "Wednesday", start: "14:00", end: "15:00", room: "Room 214" },
];
const status = getRequired("#status");
const tbody = getRequired("#schedule tbody");
const nextBooking = makeCounter();
tbody.addEventListener("click", async (event) => {
    const target = event.target; // EventTarget | null
    if (!(target instanceof Element))
        return; // now: Element
    const button = target.closest("button[data-day]"); // HTMLButtonElement | null
    const row = target.closest("tr"); // HTMLTableRowElement | null
    if (button === null || row === null)
        return;
    const slot = slots.find((s) => s.day === button.dataset.day); // Slot | undefined
    if (slot === undefined)
        return;
    status.textContent = `Updating ${slot.day}…`;
    await delay(1000);
    const booked = row.classList.toggle("selected");
    const count = document.querySelectorAll("#schedule tr.selected").length;
    status.textContent = booked
        ? `Booking #${nextBooking()} confirmed: ${describeSlot(slot)}. ${count} of ${slots.length} slots booked.`
        : `Booking for ${slot.day} cancelled. ${count} of ${slots.length} slots booked.`;
});
