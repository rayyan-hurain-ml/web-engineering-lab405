// utils.ts – typed helpers shared by main.ts and feedback.ts
/** Resolve after `ms` milliseconds. */
export const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
/** Return a function that counts 1, 2, 3, … each time it is called. */
export function makeCounter() {
    let count = 0;
    return () => ++count;
}
/**
 * querySelector that never returns null.
 * The caller chooses the element type: getRequired<HTMLInputElement>("#name").
 */
export function getRequired(selector, root = document) {
    const element = root.querySelector(selector);
    if (element === null) {
        throw new Error(`Missing element: ${selector}`);
    }
    return element;
}
export function describeSlot(slot) {
    return `${slot.day} ${slot.start}–${slot.end}, ${slot.room}`;
}
